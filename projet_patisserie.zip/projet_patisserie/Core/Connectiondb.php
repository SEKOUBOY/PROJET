<?php

// Déclaration de l'espace de noms pour la structure de l'application.
namespace App\Core;

// Extension de la classe PDO native pour la gestion de la base de données.
class Connectiondb extends \PDO
{
    // Propriétés de connexion à la base de données.
    protected $dbhost = 'localhost';
    protected $dbname = 'projet_patisserie';
    protected $dbuser = 'root';
    protected $dbpass = '';
    protected $dbcharset = 'utf8';
    
    // Propriété statique pour conserver l'instance unique.
    protected static $instance;

    // Constructeur de la classe.
    public function __construct()
    {
        // Construction du DSN pour PDO basé sur les propriétés de la classe.
        $dsn = 'mysql:host=' . $this->dbhost . ';dbname=' . $this->dbname . ';charset=' . $this->dbcharset;
        try {
            // Création d'une nouvelle instance PDO avec le DSN, utilisateur et mot de passe.
            self::$instance = new \PDO($dsn, $this->dbuser, $this->dbpass);
            // Configuration du mode d'erreur pour lever des exceptions.
            self::$instance->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
            // Configuration du mode de récupération par défaut pour les résultats en tableau associatif.
            self::$instance->setAttribute(\PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_ASSOC);
        } catch (\PDOException $e) {
            // En cas d'erreur de connexion, affiche un message d'erreur.
            echo 'Erreur : ' . $e->getMessage();
        }
    }

    // Méthode pour obtenir l'instance PDO unique.
    public static function getInstance(): \PDO
    {
        // Si l'instance n'a pas encore été créée, on la construit.
        if (is_null(self::$instance)) {
            self::$instance = new Connectiondb();
        }
        // Retourne l'instance unique de la connexion.
        return self::$instance;
    }
}

?>
