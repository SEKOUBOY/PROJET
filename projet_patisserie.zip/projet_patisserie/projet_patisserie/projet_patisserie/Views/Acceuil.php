<?php use App\Controllers\ProductsFunctions;
use App\Models\ModelProducts;

function getLimitedProducts($allproducts, $limit = 20, $offset = 0)
{
    $start = $offset;
    $end = $offset + $limit;
    return array_slice($allproducts, $start, $end);
}
$allproducts = ProductsFunctions::getAllproducts(); // Assuming getAllproducts returns all products
$products_per_page = 12; // Adjusted to limit to 20 products per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $products_per_page;

$produits = getLimitedProducts($allproducts, $products_per_page, $offset);
$total_products = count($allproducts);

$utilisateur = isset($_SESSION['user']) ? $_SESSION['user'] : null;
$isAdmin = isset($_SESSION['isAdmin']) && $_SESSION['isAdmin'] === true ? true : false;

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patisserie</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            min-height: 100vh;
            background-color: #f8f9fa;
        }
        .navbar-custom {
            background-color: #563d7c;
        }
        .card {
            transition: transform 0.3s;
            border: none;
            border-radius: 10px;
            overflow: hidden;
        }
        .card:hover {
            transform: scale(1.03);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.12);
        }
        .card-img-top {
            height: 250px;
            object-fit: cover;
        }
        .card-title {
            color: #333;
            font-size: 1.2rem;
            font-weight: 600;
        }
        .card-text {
            color: #555;
        }
        .page-item.active .page-link {
            background-color: #563d7c;
            border-color: #563d7c;
        }
        .page-link {
            color: #563d7c;
        }
        .page-link:hover {
            color: #322659;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
        <div class="container">
            <a class="navbar-brand" href="#">Patisserie Algérienne</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <?php if (isset($utilisateur)) : ?>
                        <a class="nav-link" href="./Views/cart.php">
                            <i class="fas fa-shopping-cart"></i> Panier
                            <?php
                            $cartItemCount = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;
                            echo "($cartItemCount)";
                            ?>
                        </a>
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <?= htmlspecialchars($utilisateur['email']); ?>
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="userDropdown">
                            <?php if ($isAdmin) : ?>
                                <li><a class="dropdown-item" href="#">User: Admin</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="./Views/AdminFeatures.php">Admin Features</a></li>
                            <?php else : ?>
                                <li><a class="dropdown-item" href="#">
                                    <?= htmlspecialchars($utilisateur['username']); ?>
                                </a></li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="./Views/Logout.php">Logout</a></li>
                        </ul>
                    <?php else : ?>
                        <a class="nav-link" href="./Views/Login.php">Login</a>
                        <a class="nav-link" href="./Views/Register.php">Register</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row g-4">
            <?php foreach ($produits as $produit) : ?>
                <div class="col-md-3">
                    <div class="card h-100">
                        <img src="./Public/images/<?= htmlspecialchars($produit['photos'][0]['file_path']) ?>" alt="<?= htmlspecialchars($produit['name']) ?>" class="card-img-top">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title"><?= htmlspecialchars($produit['name']) ?></h5>
                            <p class="card-text mt-auto">Prix: <?= htmlspecialchars($produit['price']) ?>$</p>
                            <a href="./Views/ProductDetails.php?id=<?= htmlspecialchars($produit['products_id']) ?>" class="btn btn-primary mt-2">Voir le produit</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
