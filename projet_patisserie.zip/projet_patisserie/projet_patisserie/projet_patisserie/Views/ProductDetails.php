<?php
require_once '../Controllers/ProductsFunctions.php';
require_once '../autoloader.php';

use App\Autoloader;
use App\Controllers\ProductsFunctions;

Autoloader::register();

session_start();
$utilisateur = isset($_SESSION['user']) ? $_SESSION['user'] : null;
$isAdmin = isset($_SESSION['isAdmin']) && $_SESSION['isAdmin'] === true ? true : false;

if (isset($_GET['id'])) {
    $product_id = $_GET['id'];
    $product = ProductsFunctions::getProductById($product_id);
} else {
    header("Location: index.php");
    exit;
}
if (isset($_POST['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];


    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    if (isset($_POST['product_id']) && isset($_POST['quantity'])) {
        $product_id = $_POST['product_id'];
        $quantity = (int)$_POST['quantity'];

        // Validation de base
        if ($quantity > 0) {
            if (!isset($_SESSION['cart'])) {
                $_SESSION['cart'] = [];
            }

            // Utilisez le product_id pour l'index du panier
            if (isset($_SESSION['cart'][$product_id])) {
                $_SESSION['cart'][$product_id]['quantity'] += $quantity;
            } else {
                $_SESSION['cart'][$product_id] = [
                    'product_id' => $product_id,
                    'quantity' => $quantity,
                    'price' => $product['price'],
                ];
            }
            // Affichez une confirmation ou redirigez vers une autre page
            echo "<script>alert('Produit ajouté au panier.'); window.location.href = 'cart.php';</script>";
        } else {
            echo "<script>alert('Quantité invalide.');</script>";
        }
    }
    header("Location: ../index.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Details</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .product-image {
            max-width: 300px;
            margin: 0 auto;
        }

        .product-image img {
            width: 100%;
            height: auto;
        }

        body {
            min-height: 100vh;
            background-color: #f8f9fa;
        }
        .navbar-custom {
            background-color: #563d7c;
        }
        .card {
            transition: transform 0.3s;
            border: none;
            border-radius: 10px;
            overflow: hidden;
        }
        .card:hover {
            transform: scale(1.03);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.12);
        }
        .card-img-top {
            height: 250px;
            object-fit: cover;
        }
        .card-title {
            color: #333;
            font-size: 1.2rem;
            font-weight: 600;
        }
        .card-text {
            color: #555;
        }
        .page-item.active .page-link {
            background-color: #563d7c;
            border-color: #563d7c;
        }
        .page-link {
            color: #563d7c;
        }
        .page-link:hover {
            color: #322659;
        }
    </style>

</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
        <a class="navbar-brand" href="../index.php">My E-commerce Site</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <?php if (isset($utilisateur)) : ?>
                    <li class="nav-item">
                        <a class="nav-link" href="cart.php">
                            <i class="fas fa-shopping-cart"></i>
                            Cart
                            <?php
                            $cartItemCount = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;
                            echo "($cartItemCount)";
                            ?>
                        </a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?= htmlspecialchars($utilisateur['email']); ?>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="userDropdown">
                            <?php if (isset($isAdmin) && $isAdmin) : ?>
                                <a class="dropdown-item" href="#">User: Admin</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="./AdminFeatures.php">Admin Features</a>
                            <?php else : ?>
                                <a class="dropdown-item" href="#">
                                    <?= htmlspecialchars($utilisateur['nom']); ?>
                                </a>
                                <a class="dropdown-item" href="#">
                                    <?= htmlspecialchars($utilisateur['telephone']); ?>
                                </a>
                            <?php endif; ?>
                            <div class="dropdown-divider"></div>
                            <li><a class="dropdown-item" href="Logout.php">Logout</a></li>
                        </div>
                    </li>

                <?php else : ?>
                    <li class="nav-item">
                        <a class="nav-link" href="./Login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./Register.php">Register</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
    <!-- Product Details -->
    <div class="container mt-5">
        <h2><?= htmlspecialchars($product['name']) ?></h2>

        <!-- Product Images Carousel -->
        <div class="product-image">
            <div id="productCarousel" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <?php
                    $isActive = true;
                    foreach ($product['photos'] as $photo) :
                    ?>
                        <div class="carousel-item <?= $isActive ? 'active' : '' ?>">
                            <img src="../Public/images/<?= htmlspecialchars($photo['file_path']) ?>" class="d-block w-100" alt="<?= htmlspecialchars($product['name']) ?>">
                        </div>
                    <?php
                        $isActive = false;
                    endforeach;
                    ?>
                </div>
                <a class="carousel-control-prev" href="#productCarousel" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#productCarousel" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>

        <!-- Product Details Form -->
        <form method="post">
            <input type="hidden" name="product_id" value="<?= $product_id ?>">

            <div class="form-group">
                <label for="quantity">Quantité :</label>
                <input type="number" class="form-control" id="quantity" name="quantity" value="1" min="1">
            </div>

            
            <p><strong>Prix:</strong> <?= htmlspecialchars($product['price']) ?>$</p>
            <p><strong>Description:</strong> <?= htmlspecialchars($product['description']) ?></p>
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-shopping-cart"></i> Ajouter au panier
            </button>
        </form>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white mt-5 p-4 text-center">
        © 2023 E-commerce Site. All Rights Reserved.
    </footer>

    <!-- Bootstrap JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>