<?php

use App\Models\Modeluser;

class UsersFunctions
{
    // Méthode pour connecter un utilisateur. Prend en entrée email et mot de passe.
    public static function login($email, $password)
    {
        // Crée une instance du modèle utilisateur avec l'email et le mot de passe donnés.
        $user = new Modeluser([
            'email' => $email,
            'password' => $password
        ]);
        // Appelle la méthode loginUser() de l'objet Modeluser pour effectuer la connexion.
        return $user->loginUser();
    }

    // Méthode pour enregistrer un nouvel utilisateur avec un nom d'utilisateur, email et mot de passe.
    public static function register($username, $email, $password)
    {
        // Crée une instance du modèle utilisateur avec les données fournies.
        $user = new Modeluser([
            'username' => $username,
            'email' => $email,
            'password' => $password
        ]);
        // Appelle la méthode insertUser() pour créer un nouveau compte utilisateur dans la base de données.
        return $user->insertUser();
    }

    // Méthode pour récupérer tous les utilisateurs de la base de données.
    public static function getAllUsers()
    {
        // Crée une instance du modèle utilisateur.
        $user = new Modeluser();
        // Appelle la méthode getAllUsers() qui retourne tous les utilisateurs enregistrés.
        return $user->getAllUsers();
    }
}
?>
