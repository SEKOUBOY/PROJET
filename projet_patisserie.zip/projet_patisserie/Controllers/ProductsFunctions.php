<?php 

namespace App\Controllers;

use App\Models\ModelProducts;

class ProductsFunctions
{
    // Cette méthode statique fait appel à la méthode correspondante dans le modèle ModelProducts pour obtenir tous les produits.
    public static function getAllproducts()
    { 
       // Appelle la méthode getAllproducts() du modèle ModelProducts qui retourne tous les produits de la base de données.
       return ModelProducts::getAllproducts();
    }

    // Cette méthode statique récupère un produit par son ID en utilisant le modèle ModelProducts.
    public static function getProductById($products_id): array
    {
        // Appelle la méthode getProductById() du modèle ModelProducts avec l'ID du produit spécifié.
        // Cela retourne les détails du produit correspondant à cet ID.
        $p = ModelProducts::getProductById($products_id);
        return $p;
    }

    // Cette méthode statique insère un nouveau produit dans la base de données en utilisant les données fournies.
    public static function insertOne(array $data): int
    {
        // Appelle la méthode insertProduct() du modèle ModelProducts avec les données du nouveau produit.
        // Cela crée une nouvelle entrée dans la base de données et retourne l'ID du produit inséré.
        return ModelProducts::insertProduct($data);
    }
}
?>
