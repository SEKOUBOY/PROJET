<?php
namespace App\Controllers;

use App\Models\ModelCommande;

class CommandeFunctions
{
    // Insère une nouvelle commande dans la base de données et retourne son ID
    public static function insertOne($data, $user_id): int
    {
        $total_price = 0; // Initialise le prix total de la commande

        // Prépare les données pour créer une commande avec l'ID de l'utilisateur et la date courante
        $commandData = [
            'user_id' => $user_id,
            'order_date' => date('Y-m-d H:i:s'),
        ];

        // Calcule le prix total en fonction des produits et quantités commandés
        foreach ($data as $item) {
            $product_id = $item["product_id"];
            $quantity = $item["quantity"];
            $price = $item["price"];

            if (isset($price)) {
                $total_price += $price * $quantity; // Ajoute au prix total
            } else {
                echo "Prix non défini pour le produit avec product_id $product_id."; // Gère l'erreur
            }
        }

        $commandData['total_price'] = $total_price; // Ajoute le prix total aux données de la commande

        // Crée une commande et tente d'insérer dans la base de données
        $commande = new ModelCommande($commandData);
        $commandId = $commande->insertHydrate(); // Retourne l'ID de la commande insérée

        // Si l'insertion est réussie, insère les éléments de la commande dans la base de données
        if ($commandId) {
            $commande->insertCommandeItems($commandId, $data); // Insère les détails de la commande
        }

        return $commandId ?? null; // Retourne l'ID de la commande ou null si échec
    }

    // Récupère toutes les commandes de la base de données
    public static function getAll(): array
    {
        $commande = new ModelCommande([]); // Crée une instance de ModelCommande
        return $commande->getAll(); // Retourne toutes les commandes
    }
}
?>
