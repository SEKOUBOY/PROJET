<?php

use App\Autoloader;
use App\Controllers\ProductsFunctions;

require_once __DIR__ . '/autoloader.php';
App\Autoloader::register();
// Lance la session
session_start();
require_once __DIR__ . '/Views/Acceuil.php';
