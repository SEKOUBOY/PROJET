<?php
// Autoload class
namespace App;

class Autoloader {
    /**
     * Registers the autoloader function with PHP.
     */
    public static function register() {
        spl_autoload_register([self::class, 'autoload']);
    }

    /**
     * Autoloads the given class file.
     *
     * @param string $class The fully-qualified name of the class to load.
     */
    public static function autoload($class) {
        // Base directory for the namespace prefix
        $base_dir = __DIR__ . '/';

        // Does the class use the namespace prefix?
        $len = strlen(__NAMESPACE__);
        if (strncmp(__NAMESPACE__, $class, $len) !== 0) {
            // No, move to the next registered autoloader
            return;
        }

        // Get the relative class name
        $relative_class = substr($class, $len);

        // Replace the namespace prefix with the base directory, replace namespace
        // separators with directory separators in the relative class name, append
        // with .php
        $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

        // If the file exists, require it
        if (file_exists($file)) {
            require $file;
        }
    }
}

// Register the autoloader
Autoloader::register();
