<?php

namespace App\Models;

class Modelcommande extends Model
{
    protected $table = "commands";
    public $commande_id;
    public $user_id;
    public $total_price;
    public $order_date;

    public function __construct(array $data)
    {
        $this->user_id = $data['user_id'] ?? null;
        $this->total_price = $data['total_price'] ?? null;
        // Date de maintenant
        $this->order_date = date('Y-m-d H:i:s');
        parent::__construct();
    }

    public static function createcommande(array $data, array $items): int
    {
        // Créer une instance de la classe pour la commandee principale
        $commande = new self([
            'user_id' => $data['user_id'],
            'total_price' => $data['total_price'],
        ]);

        // Insérer la commandee principale dans la table "commandes"
        $commandeId = $commande->insertHydrate();

        // Si l'insertion a réussi, insérer les articles de commandee dans la table "commande_items"
        if ($commandeId) {
            $commande->insertcommandeItems($commandeId, $items);
        }

        return $commandeId;
    }

    public function insertcommandeItems(int $commandeId, array $items): void
    {
        foreach ($items as $item) {
            $commandeItem = new Modelcommande_id([
                'commande_id' => $commandeId,
                'products_id' => $item['product_id'],
                'quantity' => $item['quantity'],
            ]);

            // Insérer l'article de commande dans la table "commande_items"
            $commandeItem->insertHydrate();
        }
    }
}
