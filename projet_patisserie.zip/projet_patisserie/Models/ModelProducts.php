<?php

namespace App\Models;
// Class Modelproduct
class ModelProducts extends Model
{
    protected $table = 'products';
    public $products_id;
    public $name;
    public $price;
    public $description;
    public $photo_id;
    public $file_path;
    // Constructeur
    public function __construct(array $data = [])
    {
        // On Initialise les propriétés avec des valeurs par défaut ou null
        $this->products_id = $data['products_id'] ?? null;
        $this->name = $data['name'] ?? null;
        $this->price = $data['price'] ?? null;
        $this->description = $data['description'] ?? null;
        $this->photo_id = $data['photo_id'] ?? null;
        $this->file_path = $data['file_path'] ?? null;
        // On appelle le constructeur de la classe parente
        parent::__construct();
    }
    // CRUD
    // Get products
    public function getproductByClassData(): array
    {
        $criteria = [];
        // On verifie si product_id est pas undefined sans generer d'erreur
        if (isset($this->products_id)) {
            $criteria['products_id'] = $this->products_id;
        } elseif (isset($this->name)) {
            $criteria['name'] = $this->name;
        } else {
            return []; // Aucun critère spécifié, retourner un tableau vide
        }
        // On recupere les données de la table products
        $products = $this->getproductById($criteria['products_id']);
        // On verifie si $products existe pas
        // On recupere les données de la table photos directement avec la fonction requete
        $photo = [];
        if ($products['products_id']) {
            $photo = $this->requete("SELECT * FROM photos WHERE products_id = {$products['products_id']}")->fetchAll();
        }
        $products = array_merge($products, ['photo' => $photo[0] ?? null]);
        // On hydrate l'objet
        $this->hydrate($products);
        // On retourne les données
        return $products ? $products : [];
    }
    // Get All products
    public static function getAllproducts(): array
    {
        $products = (new self())->requete("SELECT products.products_id, products.name, products.price, products.description, photos.photo_id, photos.file_path FROM products LEFT JOIN photos ON products.products_id = photos.products_id")->fetchAll();

        // Organiser les résultats par products_id
        $groupedproducts = [];
        foreach ($products as $row) {
            $productsId = $row['products_id'];

            // Ajouter le vêtement s'il n'est pas encore dans le tableau
            if (!isset($groupedproducts[$productsId])) {
                $groupedproducts[$productsId] = [
                    'products_id' => $row['products_id'],
                    'name' => $row['name'],
                    'price' => $row['price'],
                    'description' => $row['description'],
                    'photos' => [], // Créer un tableau pour stocker les photos
                ];
            }

            // Ajouter la photo au tableau des photos pour le vêtement
            $groupedproducts[$productsId]['photos'][] = [
                'photo_id' => $row['photo_id'],
                'file_path' => $row['file_path'],
            ];
        }

        return array_values($groupedproducts); // Retourner les valeurs du tableau associatif pour obtenir un tableau numérique
    }
    // Get products By Id
    public static function getproductById($productId): array
    {
        // On récupère les données de la table products
        $products = (new self())->requete("SELECT products.products_id, products.name, products.price, products.description, photos.photo_id, photos.file_path FROM products LEFT JOIN photos ON products.products_id = photos.products_id WHERE products.products_id = {$productId}")->fetchAll();

        
        // On vérifie si $products n'existe pas
        if (!$products) {
            return [];
        }

        // On initialise le tableau des photos
        $photos = [];

        // On parcourt les résultats pour récupérer toutes les photos liées au vêtement
        foreach ($products as $product) {
            // On ajoute chaque photo au tableau des photos
            $photos[] = [
                'photo_id' => $product['photo_id'],
                'file_path' => $product['file_path']
            ];
        }

        // On retourne les données avec le tableau complet des photos
        return [
            'products_id' => $products[0]['products_id'],
            'name' => $products[0]['name'],
            'price' => $products[0]['price'],
            'description' => $products[0]['description'],
            'photos' => $photos
        ];
    }


    // Insert product
    public static function insertproduct(array $data): int
    {
        // On recupere les données de la table products (name, price, description)
        $productId = (new self([
            'name' => $data['name'],
            'price' => $data['price'],
            'description' => $data['description']
        ]))->insertHydrate();
        // On insere les données de la table photos qui recoit un tableau d'image (file_path) et l'ID du vêtement
        foreach ($data['file_path'] as $file_path) {
            // Pour chaque image, on cree une instance de la classe Modelproduct avec les données de la table photos
            (new self([
                'products_id' => $productId,
                'file_path' => $file_path
            ]))->setTable("photos")->insertHydrate();
        }
        // On retourne l'ID du vêtement
        return $productId;
    }
    // Update products
    // Nouvelle méthode pour mettre à jour la table 'photos'
    public function updatePhoto($productId, $data): int
    {
        // On met à jour les données de la table photos (file_path)
        return (new self([
            'products_id' => $productId,
            'file_path' => $data['file_path']
        ]))->setTable("photos")->updateHydrate([
            'products_id' => $productId
        ]);
    }
    // Méthode pour mettre à jour les données de la table 'products' et 'photos'
    public static function updateproduct($productId, $data): array
    {
        // Les données non mises à jour sont récupérées avec les anciennes
        $product = (new self(["products_id" => $productId]))->getproductByClassData();
        // Si $product est vide, on arrête tout, sinon, on récupère ses photos
        if (!$product) {
            return [];
        }
        // On récupère les données de la table photos directement avec la fonction requête
        $photo = (new self())->requete("SELECT * FROM photos WHERE products_id = {$product['products_id']}")->fetchAll();
        // On fusionne les deux tableaux
        $product = array_merge($product, ['photo' => $photo]);
        // On vérifie les données à mettre à jour
        $product['name'] = $data['name'] ?? $product['name'];
        $product['price'] = $data['price'] ?? $product['price'];
        $product['description'] = $data['description'] ?? $product['description'];
        $product['file_path'] = $data['file_path'] ?? $product['photo']['file_path'];
        // On met à jour les données de la table 'products'
        (new self([
            'name' => $product['name'],
            'price' => $product['price'],
            'description' => $product['description']
        ]))->updateHydrate([
            'products_id' => $productId
        ]);
        // On met à jour les données de la table 'photos'
        (new self([
            'products_id' => $productId,
            'file_path' => $product['file_path']
        ]))->setTable("photos")->updateHydrate([
            'products_id' => $productId
        ]);
        // On récupère le nouveau vêtement
        return (new self(["products_id" => $productId]))->getproductByClassData();
    }
    // Delete products
    public static function deleteproduct($productId): int
    {
        // On supprime les données de la table products
        return (new self())->delete([
            'products_id' => $productId
        ]);
    }
    /**
     * Get the value of table
     */
    public function getTable()
    {
        return $this->table;
    }
    /**
     * Set the value of table
     * @return  self
     */
    public function setTable($table)
    {
        $this->table = $table;
        return $this;
    }
    /**
     * Get the value of products_id
     */
    public function getproducts_id()
    {
        return $this->products_id;
    }
    /**
     * Set the value of products_id
     * @return  self
     */
    public function setproducts_id($products_id)
    {
        $this->products_id = $products_id;
        return $this;
    }
    /**
     * Get the value of name
     */
    public function getName()
    {
        return $this->name;
    }
    /**
     * Set the value of name
     * @return  self
     */
    public function setName($name)
    {
        $this->name = $name;
        return $this;
    }
    /**
     * Get the value of price
     */
    public function getPrice()
    {
        return $this->price;
    }
    /**
     * Set the value of price
     * @return  self
     */
    public function setPrice($price)
    {
        $this->price = $price;
        return $this;
    }
    
    /**
     * Get the value of description
     */
    public function getDescription()
    {
        return $this->description;
    }
    /**
     * Set the value of description
     * @return  self
     */
    public function setDescription($description)
    {
        $this->description = $description;
        return $this;
    }
    /**
     * Get the value of photo_id
     */
    public function getPhoto_id()
    {
        return $this->photo_id;
    }
    /**
     * Set the value of photo_id
     * @return  self
     */
    public function setPhoto_id($photo_id)
    {
        $this->photo_id = $photo_id;
        return $this;
    }
    /**
     * Get the value of file_path
     */
    public function getFile_path()
    {
        return $this->file_path;
    }
    /**
     * Set the value of file_path
     * @return  self
     */
    public function setFile_path($file_path)
    {
        $this->file_path = $file_path;
        return $this;
    }
}
