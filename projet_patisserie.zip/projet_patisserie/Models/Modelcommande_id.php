<?php

namespace App\Models;

// La classe ModelCommande_id est spécialisée pour la table 'command_items' dans la base de données.
class ModelCommande_id extends Model
{
    // Définit le nom de la table à utiliser pour les opérations CRUD.
    protected $table = "command_items";

    // Déclare des propriétés représentant les colonnes de la table 'command_items'.
    public $command_item_id;
    public $command_id;
    public $products_id;
    public $quantity;

    // Le constructeur initialise l'objet avec les données fournies ou avec des valeurs par défaut null.
    public function __construct(array $data)
    {
        // Initialise les propriétés de l'objet avec les données fournies dans le tableau $data.
        $this->command_id = $data['command_id'] ?? null;
        $this->products_id = $data['products_id'] ?? null;
        $this->quantity = $data['quantity'] ?? null;
         // Appelle le constructeur parent (de la classe Model) pour établir la connexion à la base de données.
        parent::__construct();
    }
}
